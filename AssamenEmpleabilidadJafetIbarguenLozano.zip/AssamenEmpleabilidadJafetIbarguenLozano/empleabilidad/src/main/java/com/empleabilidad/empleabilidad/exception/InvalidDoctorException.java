package com.empleabilidad.empleabilidad.exception;

public class InvalidDoctorException extends RuntimeException {

  public InvalidDoctorException(String message) {
    super(message);
  }

  public InvalidDoctorException(String message, Throwable cause) {
    super(message, cause);
  }
}
