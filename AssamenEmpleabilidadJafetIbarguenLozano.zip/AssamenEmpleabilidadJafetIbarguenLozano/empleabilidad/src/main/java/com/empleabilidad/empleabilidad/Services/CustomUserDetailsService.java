package com.empleabilidad.empleabilidad.Services;


import com.empleabilidad.empleabilidad.Dtos.DoctorDTO;
import com.empleabilidad.empleabilidad.Dtos.PatientDTO;
import com.empleabilidad.empleabilidad.Models.Doctor;
import com.empleabilidad.empleabilidad.Models.Patient;
import com.empleabilidad.empleabilidad.Repositories.DoctorRepository;
import com.empleabilidad.empleabilidad.Repositories.PatientRepository;
import com.empleabilidad.empleabilidad.Utils.CustomDatails.CustomUserDetails;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    private final PatientRepository patientRepository;
    private final DoctorRepository doctorRepository;

    public CustomUserDetailsService(PatientRepository patientRepository, DoctorRepository doctorRepository) {
        this.patientRepository = patientRepository;
        this.doctorRepository = doctorRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        Optional<Patient> patient = patientRepository.findByEmail(email);
        if (patient != null) {
            PatientDTO patientDTO = mapToPatientDTO(patient);
            return new CustomUserDetails(patientDTO.getEmail(), patientDTO.getName(), "ROLE_PATIENT");
        }

        Optional<Doctor> doctor = doctorRepository.findByEmail(email);
        if (doctor != null) {
            DoctorDTO doctorDTO = mapToDoctorDTO(doctor);
            return new CustomUserDetails(doctorDTO.getEmail(), doctorDTO.getName(), "ROLE_DOCTOR");
        }

        throw new UsernameNotFoundException("User not found with email: " + email);
    }

    private PatientDTO mapToPatientDTO(Optional<Patient> patient) {
        PatientDTO dto = new PatientDTO();
        dto.setId(patient.get().getId());
        dto.setName(patient.get().getName());
        dto.setEmail(patient.get().getEmail());
        dto.setPhone(patient.get().getPhone());
        dto.setAppointmentIds(patient.get().getAppointments().stream().map(a -> a.getId()).toList());
        return dto;
    }

    private DoctorDTO mapToDoctorDTO(Optional<Doctor> doctor) {
        DoctorDTO dto = new DoctorDTO();
        dto.setId(doctor.get().getId());
        dto.setName(doctor.get().getName());
        dto.setEmail(doctor.get().getEmail());
        dto.setSpecialty(doctor.get().getSpecialty());
        dto.setAvailableFrom(doctor.get().getAvailableFrom());
        dto.setAvailableTo(doctor.get().getAvailableTo());
        dto.setAppointmentIds(doctor.get().getAppointments().stream().map(a -> a.getId()).toList());
        return dto;
    }
}
