package com.empleabilidad.empleabilidad.Dtos;


import lombok.Data;

import java.time.LocalTime;
import java.util.List;

@Data
public class DoctorDTO {
    private Long id;
    private String name;
    private String email;
    private String password;
    private String specialty;
    private LocalTime availableFrom;
    private LocalTime availableTo;
    private List<Long> appointmentIds;
}
