package com.empleabilidad.empleabilidad.Services;

import com.empleabilidad.empleabilidad.Dtos.DoctorDTO;
import com.empleabilidad.empleabilidad.exception.InvalidDoctorException;
import com.empleabilidad.empleabilidad.exception.ResourceNotFoundException;
import com.empleabilidad.empleabilidad.Models.Doctor;
import com.empleabilidad.empleabilidad.Repositories.DoctorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DoctorService {
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    private final DoctorRepository doctorRepository;

    public List<DoctorDTO> getAllDoctors() {
        return doctorRepository.findAll().stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    public DoctorDTO getDoctorById(Long id) {
        Doctor doctor = doctorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found with id: " + id));
        return mapToDTO(doctor);
    }

    public DoctorDTO createDoctor(DoctorDTO doctorDTO) {
        // Validación de existencia del correo
        if (doctorRepository.existsByEmail(doctorDTO.getEmail())) {
            throw new InvalidDoctorException("Doctor email already exists");
        }

        // Validación de existencia del nombre de usuario
        if (doctorRepository.existsByName(doctorDTO.getName())) {
            throw new InvalidDoctorException("Doctor name already exists");
        }

        Doctor doctor = mapToEntity(doctorDTO);

        doctor.setPassword(passwordEncoder.encode(doctorDTO.getPassword()));

        Doctor savedDoctor = doctorRepository.save(doctor);

        return mapToDTO(savedDoctor);
    }

    public DoctorDTO updateDoctor(Long id, DoctorDTO doctorDTO) {
        Doctor existingDoctor = doctorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found with id: " + id));

        // Validación de existencia del correo
        if (doctorRepository.existsByEmail(doctorDTO.getEmail()) && !existingDoctor.getEmail().equals(doctorDTO.getEmail())) {
            throw new InvalidDoctorException("Doctor email already exists");
        }

        // Validación de existencia del nombre de usuario
        if (doctorRepository.existsByName(doctorDTO.getName()) && !existingDoctor.getName().equals(doctorDTO.getName())) {
            throw new InvalidDoctorException("Doctor name already exists");
        }

        existingDoctor.setName(doctorDTO.getName());
        existingDoctor.setEmail(doctorDTO.getEmail());
        existingDoctor.setSpecialty(doctorDTO.getSpecialty());
        existingDoctor.setAvailableFrom(doctorDTO.getAvailableFrom());
        existingDoctor.setAvailableTo(doctorDTO.getAvailableTo());

        Doctor updatedDoctor = doctorRepository.save(existingDoctor);
        return mapToDTO(updatedDoctor);
    }

    public void deleteDoctor(Long id) {
        if (!doctorRepository.existsById(id)) {
            throw new ResourceNotFoundException("Doctor not found with id: " + id);
        }
        doctorRepository.deleteById(id);
    }

    private DoctorDTO mapToDTO(Doctor doctor) {
        DoctorDTO doctorDTO = new DoctorDTO();
        doctorDTO.setId(doctor.getId());
        doctorDTO.setName(doctor.getName());
        doctorDTO.setEmail(doctor.getEmail());
        doctorDTO.setSpecialty(doctor.getSpecialty());
        doctorDTO.setAvailableFrom(doctor.getAvailableFrom());
        doctorDTO.setAvailableTo(doctor.getAvailableTo());
        return doctorDTO;
    }

    private Doctor mapToEntity(DoctorDTO doctorDTO) {
        Doctor doctor = new Doctor();
        doctor.setName(doctorDTO.getName());
        doctor.setEmail(doctorDTO.getEmail());
        doctor.setSpecialty(doctorDTO.getSpecialty());
        doctor.setAvailableFrom(doctorDTO.getAvailableFrom());
        doctor.setAvailableTo(doctorDTO.getAvailableTo());
        return doctor;
    }
}
