package com.empleabilidad.empleabilidad.Dtos;



import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Setter
@Getter
public class AppointmentResponseDTO {

    // Getters and Setters
    private Long id;
    private LocalDateTime dateTime;
    private String reason;
    private String doctorName;
    private String patientName;

    // Constructor
    public AppointmentResponseDTO(Long id, LocalDateTime dateTime, String reason, String doctorName, String patientName) {
        this.id = id;
        this.dateTime = dateTime;
        this.reason = reason;
        this.doctorName = doctorName;
        this.patientName = patientName;
    }


}
