package com.empleabilidad.empleabilidad.Repositories;


import com.empleabilidad.empleabilidad.Models.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {

    boolean existsByDoctorIdAndDateTime(Long doctorId, LocalDateTime dateTime);

    boolean existsByPatientIdAndDateTime(Long patientId, LocalDateTime dateTime);

    Optional<Appointment> findFirstByPatientIdAndIssueAndDateTimeBetween(
            Long patientId, String issue, LocalDateTime startDate, LocalDateTime endDate);

    @Query("SELECT a FROM Appointment a WHERE a.doctor.name = :doctorName")
    List<Appointment> findByDoctorName(@Param("doctorName") String doctorName);

    List<Appointment> findByPatientId(Long id);
}
