package com.empleabilidad.empleabilidad.exception;

public class InvalidPatientException extends RuntimeException {

    public InvalidPatientException(String message) {
        super(message);
    }

    public InvalidPatientException(String message, Throwable cause) {
        super(message, cause);
    }
}
