package com.empleabilidad.empleabilidad.Services;

import com.empleabilidad.empleabilidad.Dtos.PatientDTO;
import com.empleabilidad.empleabilidad.exception.InvalidPatientException;
import com.empleabilidad.empleabilidad.exception.ResourceNotFoundException;
import com.empleabilidad.empleabilidad.Models.Patient;
import com.empleabilidad.empleabilidad.Repositories.PatientRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PatientService {
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    private final PatientRepository patientRepository;

    public List<PatientDTO> getAllPatients() {
        return patientRepository.findAll().stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    public PatientDTO getPatientById(Long id) {
        Patient patient = patientRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with id: " + id));
        return mapToDTO(patient);
    }

    public PatientDTO createPatient(PatientDTO patientDTO) {
        // Validación de existencia del correo
        if (patientRepository.existsByEmail(patientDTO.getEmail())) {
            throw new InvalidPatientException("Patient email already exists");
        }

        // Validación de existencia del nombre de usuario
        if (patientRepository.existsByName(patientDTO.getName())) {
            throw new InvalidPatientException("Patient name already exists");
        }

        // Validación de la contraseña
        if (patientDTO.getPassword() == null || patientDTO.getPassword().isEmpty()) {
            throw new IllegalArgumentException("Password cannot be null or empty");
        }

        String encodedPassword = passwordEncoder.encode(patientDTO.getPassword());

        Patient patient = new Patient();
        patient.setName(patientDTO.getName());
        patient.setEmail(patientDTO.getEmail());
        patient.setPhone(patientDTO.getPhone());
        patient.setPassword(encodedPassword);

        Patient savedPatient = patientRepository.save(patient);
        return mapToDTO(savedPatient);
    }

    public PatientDTO updatePatient(Long id, PatientDTO patientDTO) {
        Patient existingPatient = patientRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with id: " + id));

        // Validación de existencia del correo
        if (patientRepository.existsByEmail(patientDTO.getEmail()) && !existingPatient.getEmail().equals(patientDTO.getEmail())) {
            throw new InvalidPatientException("Patient email already exists");
        }

        // Validación de existencia del nombre de usuario
        if (patientRepository.existsByName(patientDTO.getName()) && !existingPatient.getName().equals(patientDTO.getName())) {
            throw new InvalidPatientException("Patient name already exists");
        }

        existingPatient.setName(patientDTO.getName());
        existingPatient.setEmail(patientDTO.getEmail());
        existingPatient.setPhone(patientDTO.getPhone());

        Patient updatedPatient = patientRepository.save(existingPatient);
        return mapToDTO(updatedPatient);
    }

    public void deletePatient(Long id) {
        if (!patientRepository.existsById(id)) {
            throw new ResourceNotFoundException("Patient not found with id: " + id);
        }
        patientRepository.deleteById(id);
    }

    private PatientDTO mapToDTO(Patient patient) {
        PatientDTO patientDTO = new PatientDTO();
        patientDTO.setId(patient.getId());
        patientDTO.setName(patient.getName());
        patientDTO.setEmail(patient.getEmail());
        patientDTO.setPhone(patient.getPhone());
        return patientDTO;
    }

    private Patient mapToEntity(PatientDTO patientDTO) {
        Patient patient = new Patient();
        patient.setName(patientDTO.getName());
        patient.setEmail(patientDTO.getEmail());
        return patient;
    }
}
