package com.empleabilidad.empleabilidad.Dtos;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class AppointmentDTO {
    private Long id;

    @NotNull(message = "Fecha y hora de la cita no puede ser nula.")
    private LocalDateTime dateTime;

    @NotNull(message = "El motivo de la cita no puede ser nulo.")
    @Size(min = 5, message = "El motivo debe tener al menos 5 caracteres.")
    private String issue;

    @NotNull(message = "El ID del doctor no puede ser nulo.")
    private Long doctorId; // ID del médico

    @NotNull(message = "El ID del paciente no puede ser nulo.")
    private Long patientId; // ID del paciente
}
