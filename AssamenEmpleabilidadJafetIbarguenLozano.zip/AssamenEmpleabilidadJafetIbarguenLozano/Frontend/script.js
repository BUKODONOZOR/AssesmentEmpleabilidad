const baseUrl = "http://localhost:8080/api"; // Reemplaza con la URL de tu API

// Register
document.getElementById("registerForm").addEventListener("submit", async function (e) {
    e.preventDefault();

    const name = document.getElementById("regName").value;
    const email = document.getElementById("regEmail").value;
    const password = document.getElementById("regPassword").value;
    const specialty = document.getElementById("regSpecialty").value;
    const availableFrom = document.getElementById("regAvailableFrom").value;
    const availableTo = document.getElementById("regAvailableTo").value;


    try {
        const response = await fetch(`${baseUrl}/doctors`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, email, password ,specialty ,availableFrom ,availableTo})
        });

        const data = await response.json();
        document.getElementById("registerMessage").textContent = response.ok
            ? "Registration successful!"
            : data.message || "Registration failed.";
    } catch (error) {
        console.error("Error:", error);
        document.getElementById("registerMessage").textContent = "An error occurred.";
    }
});


