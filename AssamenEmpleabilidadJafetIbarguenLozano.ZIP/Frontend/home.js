document.addEventListener("DOMContentLoaded", async () => {
    const token = localStorage.getItem("token");

    if (!token) {
        alert("No estás autenticado. Redirigiendo al login.");
        window.location.href = "login.html";
        return;
    }

    try {
        // Decodificar el token para obtener el rol y el correo electrónico
        const tokenPayload = JSON.parse(atob(token.split(".")[1]));
        const role = tokenPayload.role;
        const email = tokenPayload.sub; // El correo del doctor o paciente logueado

        // Mostrar el rol en la página
        const roleDisplay = document.getElementById("roleDisplay");
        roleDisplay.textContent = role === "DOCTOR" ? "Doctor" : "Paciente";

        // Si es doctor, mostrar las citas
        if (role === "DOCTOR") {
            await loadAppointmentsByEmail(email, token);
        }

        // Si es paciente, mostrar las citas asignadas
        if (role === "PATIENT") {
            await loadPatientAppointments(email, token);
        }

    } catch (error) {
        console.error("Error al decodificar el token:", error);
        alert("Error de autenticación. Redirigiendo al login.");
        window.location.href = "login.html";
    }
});

// Método para cargar las citas del paciente
async function loadPatientAppointments(patientEmail, token) {
    try {
        const response = await fetch(`http://localhost:8080/api/appointments/patient/email/${patientEmail}`, {
            method: "GET",
            headers: {
                "Authorization": `Bearer ${token}`,
                "Content-Type": "application/json",
            },
        });

        if (!response.ok) {
            throw new Error(`Error al obtener citas: ${response.status}`);
        }

        const appointments = await response.json();
        renderAppointments(appointments);
    } catch (error) {
        console.error("Error al cargar las citas:", error);
        alert("No se pudieron cargar las citas.");
    }
}

function renderAppointments(appointments) {
    const container = document.getElementById("appointmentsContainer");
    const list = document.getElementById("appointmentsList");

    list.innerHTML = ""; // Limpiar la lista existente

    if (appointments.length === 0) {
        list.innerHTML = "<li>No tienes citas asignadas.</li>";
    } else {
        appointments.forEach(appointment => {
            const li = document.createElement("li");
            li.textContent = `Fecha: ${appointment.dateTime}, Motivo: ${appointment.issue}, Doctor: ${appointment.doctorName}`;
            list.appendChild(li);
        });
    }

    container.style.display = "block"; // Mostrar el contenedor de citas
}
