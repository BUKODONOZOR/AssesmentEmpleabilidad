document.addEventListener("DOMContentLoaded", () => {
    const loginForm = document.getElementById("loginForm");

    loginForm.addEventListener("submit", async (event) => {
        event.preventDefault();

        const email = document.getElementById("email").value;
        const password = document.getElementById("password").value;

        try {
            const response = await fetch("http://localhost:8080/api/auth/login", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ email, password }),
            });

            if (!response.ok) {
                throw new Error("Credenciales inválidas");
            }

            const data = await response.json();
            console.log("Inicio de sesión exitoso:", data);

            // Guarda el token en localStorage
            localStorage.setItem("token", data.token);

            // Decodifica el token para extraer el rol
            const tokenPayload = JSON.parse(atob(data.token.split(".")[1])); // Decodificar la parte del payload
            const role = tokenPayload.role; // El rol debería estar en el payload del token

            // Redirige a home.html y pasa el rol
            window.location.href = `home.html?role=${role}`;
        } catch (error) {
            console.error("Error:", error);
            alert("Error al iniciar sesión: " + error.message);
        }
    });
});
