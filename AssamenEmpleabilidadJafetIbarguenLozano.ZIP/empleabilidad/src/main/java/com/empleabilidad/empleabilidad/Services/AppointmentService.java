package com.empleabilidad.empleabilidad.Services;


import com.empleabilidad.empleabilidad.Dtos.AppointmentDTO;
import com.empleabilidad.empleabilidad.Dtos.UpdateAppointmentDTO;
import com.empleabilidad.empleabilidad.Dtos.AppointmentResponseDTO;

import com.empleabilidad.empleabilidad.exception.InvalidAppointmentException;
import com.empleabilidad.empleabilidad.exception.ResourceNotFoundException;

import com.empleabilidad.empleabilidad.Models.Appointment;
import com.empleabilidad.empleabilidad.Models.Doctor;
import com.empleabilidad.empleabilidad.Models.Patient;
import com.empleabilidad.empleabilidad.Repositories.AppointmentRepository;
import com.empleabilidad.empleabilidad.Repositories.DoctorRepository;
import com.empleabilidad.empleabilidad.Repositories.PatientRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AppointmentService {

    private final AppointmentRepository appointmentRepository;
    private final DoctorRepository doctorRepository;
    private final PatientRepository patientRepository;


    /**
     * Retrieve all appointments.
     *
     * @return List of AppointmentResponseDTO containing all appointments.
     */
    public List<AppointmentResponseDTO> getAllAppointments() {
        List<Appointment> appointments = appointmentRepository.findAll();
        return appointments.stream()
                .map(this::convertToResponseDTO)
                .collect(Collectors.toList());
    }

    /**
     * Retrieve a single appointment by ID.
     *
     * @param id The ID of the appointment to retrieve.
     * @return AppointmentResponseDTO containing appointment details.
     * @throws ResourceNotFoundException if the appointment does not exist.
     */
    public AppointmentResponseDTO getAppointmentById(Long id) {
        Appointment appointment = appointmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Appointment not found with ID: " + id));
        return convertToResponseDTO(appointment);
    }

    /**
     * Delete an appointment by ID.
     *
     * @param id The ID of the appointment to delete.
     * @throws ResourceNotFoundException if the appointment does not exist.
     */
    public void deleteAppointment(Long id) {
        Appointment appointment = appointmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Appointment not found with ID: " + id));
        appointmentRepository.delete(appointment);
    }

    /**
     * Helper method to convert Appointment entity to AppointmentResponseDTO.
     *
     * @param appointment The appointment entity.
     * @return AppointmentResponseDTO with details of the appointment.
     */
    private AppointmentResponseDTO convertToResponseDTO(Appointment appointment) {
        return new AppointmentResponseDTO(
                appointment.getId(),
                appointment.getDateTime(),
                appointment.getIssue(),
                appointment.getDoctor().getName(),
                appointment.getPatient().getName()
        );
    }

    public Appointment createAppointment(AppointmentDTO createAppointmentDTO) {
        // Obtener entidades relacionadas
        Doctor doctor = doctorRepository.findById(createAppointmentDTO.getDoctorId())
                .orElseThrow(() -> new InvalidAppointmentException("Doctor not found"));

        Patient patient = patientRepository.findById(createAppointmentDTO.getPatientId())
                .orElseThrow(() -> new InvalidAppointmentException("Patient not found"));

        LocalDateTime appointmentDateTime = createAppointmentDTO.getDateTime();

        // Validación 1: Horario del médico
        if (appointmentDateTime.toLocalTime().isBefore(doctor.getAvailableFrom()) ||
                appointmentDateTime.toLocalTime().isAfter(doctor.getAvailableTo())) {
            throw new InvalidAppointmentException("Appointment time is outside the doctor's availability hours.");
        }

        // Validación 2: Evitar duplicados en el mismo horario
        if (appointmentRepository.existsByDoctorIdAndDateTime(doctor.getId(), appointmentDateTime) ||
                appointmentRepository.existsByPatientIdAndDateTime(patient.getId(), appointmentDateTime)) {
            throw new InvalidAppointmentException("An appointment already exists at the specified time.");
        }

        // Validación 3: Citas duplicadas para el mismo padecimiento en 2 meses
        Optional<Appointment> recentAppointment = appointmentRepository.findFirstByPatientIdAndIssueAndDateTimeBetween(
                patient.getId(),
                createAppointmentDTO.getIssue(),
                appointmentDateTime.minus(2, ChronoUnit.MONTHS),
                appointmentDateTime
        );

        if (recentAppointment.isPresent()) {
            throw new InvalidAppointmentException("A similar appointment already exists within the past 2 months.");
        }

        // Crear la cita
        Appointment appointment = new Appointment();
        appointment.setDateTime(appointmentDateTime);
        appointment.setIssue(createAppointmentDTO.getIssue());
        appointment.setDoctor(doctor);
        appointment.setPatient(patient);

        return appointmentRepository.save(appointment);
    }

    public Appointment updateAppointment(UpdateAppointmentDTO updateAppointmentDTO) {
        Appointment appointment = appointmentRepository.findById(updateAppointmentDTO.getId())
                .orElseThrow(() -> new InvalidAppointmentException("Appointment not found"));

        LocalDateTime newDateTime = updateAppointmentDTO.getDateTime();

        // Validar el horario del médico
        if (newDateTime.toLocalTime().isBefore(appointment.getDoctor().getAvailableFrom()) ||
                newDateTime.toLocalTime().isAfter(appointment.getDoctor().getAvailableTo())) {
            throw new InvalidAppointmentException("New appointment time is outside the doctor's availability hours.");
        }

        // Validar citas en el mismo horario
        if (appointmentRepository.existsByDoctorIdAndDateTime(appointment.getDoctor().getId(), newDateTime)) {
            throw new InvalidAppointmentException("Another appointment already exists at the specified time.");
        }

        appointment.setDateTime(newDateTime);
        appointment.setIssue(updateAppointmentDTO.getIssue());
        return appointmentRepository.save(appointment);
    }

    public List<AppointmentResponseDTO> getAppointmentsByDoctorName(String doctorName) {
        // Busca las citas por el nombre del doctor
        List<Appointment> appointments = appointmentRepository.findByDoctorName(doctorName);

        // Convierte las entidades Appointment en DTOs para devolver solo los datos relevantes
        return appointments.stream()
                .map(appointment -> new AppointmentResponseDTO(
                        appointment.getId(),
                        appointment.getDateTime(),
                        appointment.getIssue(),
                        appointment.getDoctor().getName(),
                        appointment.getPatient().getName()
                ))
                .collect(Collectors.toList());
    }


    public List<AppointmentResponseDTO> getAppointmentsByDoctorEmail(String email) {
        // Consulta para obtener el doctor por correo
        Doctor doctor = doctorRepository.findByEmail(email)
                .orElseThrow(() -> new EntityNotFoundException("Doctor no encontrado con el correo: " + email));

        // Obtener citas del doctor y convertirlas a DTO
        return doctor.getAppointments()
                .stream()
                .map(appointment -> new AppointmentResponseDTO(
                        appointment.getId(),
                        appointment.getDateTime(),
                        appointment.getIssue(),
                        doctor.getName(),
                        appointment.getPatient().getName()
                ))
                .collect(Collectors.toList());
    }

    public List<AppointmentDTO> getAppointmentsByPatientEmail(String email) {
        // Busca al paciente por correo electrónico
        Patient patient = patientRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Paciente no encontrado"));

        // Obtén las citas asignadas al paciente
        List<Appointment> appointments = appointmentRepository.findByPatientId(patient.getId());

        // Mapear las citas a AppointmentDTO y devolverlas
        return appointments.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    // Método para mapear Appointment a AppointmentDTO
    private AppointmentDTO mapToDTO(Appointment appointment) {
        AppointmentDTO dto = new AppointmentDTO();
        dto.setId(appointment.getId());
        dto.setDateTime(appointment.getDateTime());
        dto.setIssue(appointment.getIssue());
        dto.setDoctorId(appointment.getDoctor().getId());
        dto.setPatientId(appointment.getPatient().getId());
        return dto;
    }


}
