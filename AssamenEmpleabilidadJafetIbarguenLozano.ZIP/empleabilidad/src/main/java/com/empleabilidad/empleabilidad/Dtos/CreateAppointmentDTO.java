package com.empleabilidad.empleabilidad.Dtos;


import lombok.Data;

import java.time.LocalDateTime;

@Data
public class CreateAppointmentDTO {
    private LocalDateTime dateTime;
    private String issue;
    private Long doctorId; // ID del médico
    private Long patientId; // ID del paciente
}
