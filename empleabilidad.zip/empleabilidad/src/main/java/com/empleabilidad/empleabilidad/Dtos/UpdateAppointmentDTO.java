package com.empleabilidad.empleabilidad.Dtos;


import lombok.Data;

import java.time.LocalDateTime;

@Data
public class UpdateAppointmentDTO {
    private Long id; // ID de la cita a actualizar
    private LocalDateTime dateTime;
    private String issue;
}
