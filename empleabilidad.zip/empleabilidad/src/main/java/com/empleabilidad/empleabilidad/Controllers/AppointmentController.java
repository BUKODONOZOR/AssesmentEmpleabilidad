package com.empleabilidad.empleabilidad.Controllers;

import com.empleabilidad.empleabilidad.Dtos.AppointmentDTO;
import com.empleabilidad.empleabilidad.Dtos.AppointmentResponseDTO;
import com.empleabilidad.empleabilidad.Dtos.UpdateAppointmentDTO;
import com.empleabilidad.empleabilidad.Models.Appointment;
import com.empleabilidad.empleabilidad.Services.AppointmentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/appointments")
public class AppointmentController {

    private final AppointmentService appointmentService;

    public AppointmentController(AppointmentService appointmentService) {
        this.appointmentService = appointmentService;
    }

    @Operation(summary = "Create a new appointment")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Appointment created successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid input data")
    })
    @PostMapping
    public ResponseEntity<AppointmentResponseDTO> createAppointment(@RequestBody AppointmentDTO appointmentDTO) {
        Appointment savedAppointment = appointmentService.createAppointment(appointmentDTO);
        AppointmentResponseDTO responseDTO = new AppointmentResponseDTO(
                savedAppointment.getId(),
                savedAppointment.getDateTime(),
                savedAppointment.getIssue(),
                savedAppointment.getDoctor().getName(),
                savedAppointment.getPatient().getName()
        );
        return ResponseEntity.ok(responseDTO);
    }

    @Operation(summary = "Get all appointments")
    @ApiResponse(responseCode = "200", description = "List of appointments retrieved successfully")
    @GetMapping
    public ResponseEntity<List<AppointmentResponseDTO>> getAllAppointments() {
        List<AppointmentResponseDTO> appointments = appointmentService.getAllAppointments();
        return ResponseEntity.ok(appointments);
    }

    @Operation(summary = "Get appointment by ID")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Appointment found"),
            @ApiResponse(responseCode = "404", description = "Appointment not found")
    })
    @GetMapping("/{id}")
    public ResponseEntity<AppointmentResponseDTO> getAppointmentById(@PathVariable Long id) {
        AppointmentResponseDTO appointment = appointmentService.getAppointmentById(id);
        return ResponseEntity.ok(appointment);
    }

    @Operation(summary = "Update an existing appointment")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Appointment updated successfully"),
            @ApiResponse(responseCode = "404", description = "Appointment not found")
    })
    @PutMapping("/{id}")
    public ResponseEntity<AppointmentResponseDTO> updateAppointment(
            @PathVariable Long id,
            @RequestBody UpdateAppointmentDTO appointmentDTO) {

        appointmentDTO.setId(id);
        Appointment updatedAppointment = appointmentService.updateAppointment(appointmentDTO);
        AppointmentResponseDTO responseDTO = new AppointmentResponseDTO(
                updatedAppointment.getId(),
                updatedAppointment.getDateTime(),
                updatedAppointment.getIssue(),
                updatedAppointment.getDoctor().getName(),
                updatedAppointment.getPatient().getName()
        );
        return ResponseEntity.ok(responseDTO);
    }

    @Operation(summary = "Delete an appointment")
    @ApiResponses({
            @ApiResponse(responseCode = "204", description = "Appointment deleted successfully"),
            @ApiResponse(responseCode = "404", description = "Appointment not found")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAppointment(@PathVariable Long id) {
        appointmentService.deleteAppointment(id);
        return ResponseEntity.noContent().build();
    }

    @Operation(summary = "Get appointments by doctor's name")
    @ApiResponse(responseCode = "200", description = "Appointments retrieved successfully")
    @GetMapping("/doctor/{doctorName}")
    public ResponseEntity<List<AppointmentResponseDTO>> getAppointmentsByDoctorName(@PathVariable String doctorName) {
        List<AppointmentResponseDTO> appointments = appointmentService.getAppointmentsByDoctorName(doctorName);
        return ResponseEntity.ok(appointments);
    }

    @Operation(summary = "Get appointments by doctor's email")
    @ApiResponse(responseCode = "200", description = "Appointments retrieved successfully")
    @GetMapping("/doctor/email/{email}")
    public ResponseEntity<List<AppointmentResponseDTO>> getAppointmentsByDoctorEmail(@PathVariable String email) {
        List<AppointmentResponseDTO> appointments = appointmentService.getAppointmentsByDoctorEmail(email);
        return ResponseEntity.ok(appointments);
    }

    @Operation(summary = "Get appointments by patient's email")
    @ApiResponse(responseCode = "200", description = "Appointments retrieved successfully")
    @GetMapping("/patient/email/{email}")
    public ResponseEntity<List<AppointmentDTO>> getAppointmentsByPatientEmail(@PathVariable String email) {
        List<AppointmentDTO> appointments = appointmentService.getAppointmentsByPatientEmail(email);
        return ResponseEntity.ok(appointments);
    }
}
