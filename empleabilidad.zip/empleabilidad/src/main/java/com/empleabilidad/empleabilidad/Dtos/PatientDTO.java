package com.empleabilidad.empleabilidad.Dtos;


import lombok.Data;

import java.util.List;

@Data
public class PatientDTO {
    private Long id;
    private String name;
    private String email;
    private String phone;
    private String password;
    private List<Long> appointmentIds; // IDs de las citas asignadas
}
