package com.empleabilidad.empleabilidad.exception;


public class InvalidAppointmentException extends RuntimeException {
    public InvalidAppointmentException(String message) {
        super(message);
    }
}