package com.empleabilidad.empleabilidad.Dtos;


import lombok.Data;

import java.time.LocalTime;
import java.util.List;

@Data
public class DoctorDTO {
    private Long id;
    private String name;
    private String email;
    private String password;
    private String specialty;
    private LocalTime availableFrom; // Hora de inicio de disponibilidad
    private LocalTime availableTo; // Hora de fin de disponibilidad
    private List<Long> appointmentIds; // IDs de las citas asignadas
}
