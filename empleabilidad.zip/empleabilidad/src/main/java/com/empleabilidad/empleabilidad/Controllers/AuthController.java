package com.empleabilidad.empleabilidad.Controllers;

import com.empleabilidad.empleabilidad.Dtos.LoginDTO;
import com.empleabilidad.empleabilidad.Dtos.LoginResponse;
import com.empleabilidad.empleabilidad.Models.Doctor;
import com.empleabilidad.empleabilidad.Models.Patient;
import com.empleabilidad.empleabilidad.Repositories.DoctorRepository;
import com.empleabilidad.empleabilidad.Repositories.PatientRepository;
import com.empleabilidad.empleabilidad.Security.JwtTokenProvider;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final PatientRepository patientRepository;
    private final DoctorRepository doctorRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenProvider jwtTokenProvider;

    @Autowired
    public AuthController(PatientRepository patientRepository, DoctorRepository doctorRepository,
                          PasswordEncoder passwordEncoder, JwtTokenProvider jwtTokenProvider) {
        this.patientRepository = patientRepository;
        this.doctorRepository = doctorRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtTokenProvider = jwtTokenProvider;
    }

    @Operation(summary = "Login for patients and doctors")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Login successful"),
            @ApiResponse(responseCode = "403", description = "Invalid email or password")
    })
    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@RequestBody LoginDTO loginRequest) {
        String email = loginRequest.getEmail();
        String password = loginRequest.getPassword();

        // Verificar si el usuario es un paciente
        Patient patient = patientRepository.findByEmail(email).orElse(null);
        if (patient != null && passwordEncoder.matches(password, patient.getPassword())) {
            String token = jwtTokenProvider.generateToken(patient.getEmail(), "PATIENT");
            return ResponseEntity.ok(new LoginResponse("Login successful for patient!", token));
        }

        // Verificar si el usuario es un doctor
        Doctor doctor = doctorRepository.findByEmail(email).orElse(null);
        if (doctor != null && passwordEncoder.matches(password, doctor.getPassword())) {
            String token = jwtTokenProvider.generateToken(doctor.getEmail(), "DOCTOR");
            return ResponseEntity.ok(new LoginResponse("Login successful for doctor!", token));
        }

        return ResponseEntity.status(403).body(new LoginResponse("Invalid email or password.", null));
    }
}
